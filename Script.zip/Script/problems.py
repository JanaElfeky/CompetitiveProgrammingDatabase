import requests
import json
import csv


urlProblems = "https://codeforces.com/api/problemset.problems"
responseProb = requests.get(urlProblems)
api_response_Prob = responseProb.json()
csv_file_path_prob = 'problems_output.csv'
csv_file_path_prob_tags = 'problems_tags_output.csv'

def extract_prob_info(problems):
    extracted_info = []
    prob_info_tags = []

    for problem in problems:
        prob_id = str(problem['contestId']) + problem['index']

        for tag in problem['tags']:
            prob_info_tags.append({
            'Prob_ID_Tags': prob_id,
            'Prob_Tag': tag
        })

        extracted_info.append({
            'Prob_ID': prob_id,
            'Prob_Name': problem['name']
        })

    return extracted_info, prob_info_tags

problems = api_response_Prob["result"]["problems"]
problems_out = extract_prob_info(problems)[0]
problem_tags_out = extract_prob_info(problems)[1]

with open('problems_output.json', 'w') as g:
    json.dump(problems_out, g, indent=4)

with open('problems_output.json', 'r') as json_file_prob:
    problems = json.load(json_file_prob)


with open(csv_file_path_prob, 'w', newline='', encoding='utf-8') as csv_file_prob:
    writer_prob = csv.writer(csv_file_prob)

    for problem in problems_out:
        writer_prob.writerow([
            problem['Prob_ID'],
            problem['Prob_Name']
        ])

with open(csv_file_path_prob_tags, 'w', newline='', encoding='utf-8') as csv_file_prob_tags:
    writer_prob_tags = csv.writer(csv_file_prob_tags)

    for tag in problem_tags_out:
        writer_prob_tags.writerow([
            tag['Prob_ID_Tags'],
            tag['Prob_Tag'],
        ])
