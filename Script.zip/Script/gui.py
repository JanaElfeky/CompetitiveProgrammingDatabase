import tkinter as tk
from tkinter import ttk
import mysql.connector
from tkinter import messagebox

def connect_to_db():

    try:
        conn = mysql.connector.connect(
            host='codeforcesjana.c1ikges4mouc.eu-north-1.rds.amazonaws.com',
            user='root',
            password='codeforces',
            database='codeforcesjana'
        )
        print("Connection successful")
        return conn
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

def fetch_writer_competitions(parent):

    new_window = tk.Toplevel(parent)
    new_window.title("Contests by writer")
    new_window.geometry("300x200")

    label = ttk.Label(new_window, text="Enter Writer:")
    label.pack(side=tk.LEFT, padx=5)

    username_entry = ttk.Entry(new_window)
    username_entry.pack(side=tk.LEFT, padx=5)

    btn_fetch = ttk.Button(new_window, text='Submit',command=lambda: fetch_writers(parent, username_entry.get()))
    btn_fetch.pack(side=tk.LEFT, padx=5)
    
def fetch_writers(parent,writer):

    new_window2 = tk.Toplevel(parent)
    new_window2.title("Contests by writer")
    new_window2.geometry("400x300")
        
    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Cont_Name
        FROM Contest_Writers
        WHERE Writer = %s
        """
        cursor.execute(query, (writer,))
        results = cursor.fetchall()

        if not results:
            messagebox.showerror("No Results", f"{writer} is not a writer.")
            return  # Exit the function without creating a new window

        # Create a Treeview inside the parent widget (e.g., a tab or frame)
        tree = ttk.Treeview(new_window2, columns=('Cont_Name'), show='headings')
        tree.heading('Cont_Name', text='Contest Name')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        # Insert data into the Treeview
        for result in results:
            tree.insert('', tk.END, values=result)

    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()
        
def fetch_problems_by_tag(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Problems by Tag")
    new_window.geometry("300x200")

    label = ttk.Label(new_window, text="Enter Tag:")
    label.pack(side=tk.LEFT, padx=5)

    tag_entry = ttk.Entry(new_window)
    tag_entry.pack(side=tk.LEFT, padx=5)

    btn_fetch = ttk.Button(new_window, text='Submit',command=lambda: fetch_problems(parent, tag_entry.get()))
    btn_fetch.pack(side=tk.LEFT, padx=5)

def fetch_problems(parent,tag):
        new_window2 = tk.Toplevel(parent)
        new_window2.title("Problems by Tag")
        new_window2.geometry("400x300")


        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            query = """
                SELECT Problem.Prob_ID, Problem.Prob_Name
                FROM Problem INNER JOIN Problem_Tags
                ON Problem.Prob_ID = Problem_Tags.Prob_ID
                WHERE Tag = %s
                """
            cursor.execute(query, (tag,))
            results = cursor.fetchall()

            columns = ('Prob_ID','Prob_Name')
            # Create a Treeview inside the parent widget (e.g., a tab or frame)
            tree = ttk.Treeview(new_window2, columns=columns, show='headings')
            tree.heading('Prob_ID', text='Problem ID')
            tree.heading('Prob_Name', text='Problem Name')
            tree.pack(fill=tk.BOTH, expand=True, pady=10)

            # Insert data into the Treeview
            for result in results:
                tree.insert('', tk.END, values=result)

        except mysql.connector.Error as err:
            print(f"Error: {err}")
        finally:
            cursor.close()
            conn.close()
            
def fetch_top_user_days(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 10 users")
    new_window.geometry("500x300")

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Screen_Name, Days_In_Row
        FROM Users
        ORDER BY Days_In_Row DESC
        LIMIT 10
        """
        cursor.execute(query)
        results = cursor.fetchall()
        columns = ('Screen_Name', 'Days_In_Row')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Screen_Name', text='Screen Name')
        tree.heading('Days_In_Row', text='Days in a Row')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        # Insert data into the Treeview
        for result in results:
            tree.insert('', tk.END, values=result)

    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_top_user_probs(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 10 users")
    new_window.geometry("500x300")

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Screen_Name, Probs_Solved
        FROM Users
        ORDER BY Probs_Solved DESC
        LIMIT 10
        """
        cursor.execute(query)
        results = cursor.fetchall()
        columns = ('Screen_Name', 'Probs_Solved')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Screen_Name', text='Screen Name')
        tree.heading('Probs_Solved', text='Problems Solved')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        # Insert data into the Treeview
        for result in results:
            tree.insert('', tk.END, values=result)

    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_top_users_total_scores(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 10 users")
    new_window.geometry("400x300")

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Screen_Name, SUM(Total_Score) AS total_score
        FROM Registers
        GROUP BY Screen_Name
        ORDER BY total_score DESC
        LIMIT 10
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('Screen_Name', 'total_score')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Screen_Name', text='Screen Name')
        tree.heading('total_score', text='Total Score')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        # Insert data into the Treeview
        for result in results:
            tree.insert('', tk.END, values=result)

    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_top_organizations_by_country(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 10 users")
    new_window.geometry("700x300")

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT User_Org, User_Country, AVG(Rating) AS avg_rating
        FROM Users
        GROUP BY User_Org, User_Country
        ORDER BY avg_rating DESC
        LIMIT 5
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('User_Org', 'User_Country', 'avg_rating')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('User_Org', text='Organization')
        tree.heading('User_Country', text='Country')
        tree.heading('avg_rating', text='Average Rating')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        # Insert data into the Treeview
        for result in results:
            tree.insert('', tk.END, values=result)
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_top_auc_users(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 10 AUC users")
    new_window.geometry("700x300")

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Screen_Name, Rating
        FROM Users
        WHERE User_Org = 'American University in Cairo' OR User_Org = 'The American University in Cairo'
        ORDER BY Rating DESC
        LIMIT 10
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('Screen_Name', 'Rating')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Screen_Name', text='Screen Name')
        tree.heading('Rating', text='Rating')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_top_users_by_participation(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 5 users by participation")
    new_window.geometry("700x300")

    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Users.Screen_Name, COUNT(Registers.Cont_Name) / DATEDIFF(CURRENT_DATE, Users.reg_date) AS participation_frequency
        FROM Registers
        INNER JOIN Users ON Registers.Screen_Name = Users.Screen_Name
        GROUP BY Users.Screen_Name
        ORDER BY participation_frequency DESC
        LIMIT 5
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('Screen_Name', 'participation_frequency')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Screen_Name', text='Screen Name')
        tree.heading('participation_frequency', text='Participation Frequency')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)

    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_top_problems_from_egypt(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 5 users from Egypt")
    new_window.geometry("700x300")
    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Attempt.Prob_ID, Problem.Prob_Name, COUNT(*) AS attempt_count
        FROM Users INNER JOIN Attempt ON Attempt.Screen_Name = Users.Screen_Name
        INNER JOIN Problem ON Attempt.Prob_ID = Problem.Prob_ID
        WHERE Users.User_Country = 'Egypt'
        GROUP BY Attempt.Prob_ID
        ORDER BY attempt_count DESC
        LIMIT 5
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('Prob_ID', 'Prob_Name', 'attempt_count')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Prob_ID', text='Problem ID')
        tree.heading('Prob_Name', text='Problem Name')
        tree.heading('attempt_count', text='Number of Attempts')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()
        
def fetch_efficient_problems_speed(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 5 programming languages by memory")
    new_window.geometry("700x300")
    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT Attempt.Lang, Attempt.Att_Duration
        FROM Problem INNER JOIN Attempt ON Attempt.Prob_ID = Problem.Prob_ID
        WHERE Verdict ='OK'
        ORDER BY (Attempt.Att_Duration / Problem.Time_Limit)
        LIMIT 5
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('Lang', 'Att_Mem')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Lang', text='Language')
        tree.heading('Att_Mem', text='Attempt Memory')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def fetch_efficient_problems_mem(parent):
        new_window = tk.Toplevel(parent)
        new_window.title("Top 5 programming languages by memory")
        new_window.geometry("700x300")
        try:
            conn = connect_to_db()
            cursor = conn.cursor()
            query = """
            SELECT DISTINCT Attempt.Lang, Attempt.Att_Mem
            FROM Problem INNER JOIN Attempt ON Attempt.Prob_ID = Problem.Prob_ID
            WHERE Verdict ='OK'
            ORDER BY (Attempt.Att_Mem / Problem.Mem_Limit)
            LIMIT 5
            """
            cursor.execute(query)
            results = cursor.fetchall()

            columns = ('Lang', 'Att_Mem')

            tree = ttk.Treeview(new_window, columns=columns, show='headings')
            tree.heading('Lang', text='Language')
            tree.heading('Att_Mem', text='Attempt Memory')
            tree.pack(fill=tk.BOTH, expand=True, pady=10)

            for result in results:
                tree.insert('', tk.END, values=result)
        except mysql.connector.Error as err:
            print(f"Error: {err}")
        finally:
            cursor.close()
            conn.close()
            
def fetch_efficient_problems_speed(parent):
    new_window = tk.Toplevel(parent)
    new_window.title("Top 5 programming languages by speed")
    new_window.geometry("700x300")
    try:
        conn = connect_to_db()
        cursor = conn.cursor()
        query = """
        SELECT DISTINCT Lang, Att_Duration
        FROM Attempt
        WHERE Verdict ='OK'
        ORDER BY Att_Duration
        LIMIT 5
        """
        cursor.execute(query)
        results = cursor.fetchall()

        columns = ('Lang', 'Att_Duration')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Lang', text='Language')
        tree.heading('Att_Duration', text='Attempt Speed')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)
    except mysql.connector.Error as err:
        print(f"Error: {err}")
    finally:
        cursor.close()
        conn.close()

def login_user_and_show_options(screen_name, login_tab):
    if login_user(screen_name):  # Check if login is successful
        # Clear the login frame
        for widget in login_tab.winfo_children():
            widget.grid_forget()  # Hide all widgets in the login tab

        # Show a welcome message
        welcome_label = ttk.Label(login_tab, text=f"Welcome, {screen_name}!", font=("Helvetica", 16))
        welcome_label.pack(pady=10)

        # Add buttons for user options
        problems_button = ttk.Button(login_tab, text="View Attempted Problems",
                                     command=lambda: fetch_attempted_problems(screen_name,login_tab))
        problems_button.pack(pady=5)

        contests_button = ttk.Button(login_tab, text="View Participated Contests",
                                     command=lambda: fetch_user_competitions(screen_name,login_tab))
        contests_button.pack(pady=5)

        logout_button = ttk.Button(login_tab, text="Logout", command=lambda: logout_user(login_tab))
        logout_button.pack(pady=5)

def login_user(screen_name):
    try:
        # Connect to the database
        conn = connect_to_db()
        cursor = conn.cursor()

        # Check if the user exists
        query = "SELECT COUNT(*) FROM Users WHERE Screen_Name = %s"
        cursor.execute(query, (screen_name,))
        result = cursor.fetchone()

        if result[0] > 0:
            messagebox.showinfo("Login Successful", f"Welcome, {screen_name}!")
            return True
        else:
            messagebox.showerror("Login Failed", "Screen Name not found. Please try again.")
            return False  # Prevents the login process from continuing
    except mysql.connector.Error as err:
        messagebox.showerror("Database Error", f"Error: {err}")
        return False  # Prevents the login process from continuing
    finally:
        cursor.close()
        conn.close()

def logout_user(login_tab):
    for widget in login_tab.winfo_children():
        widget.pack_forget()


    ttk.Label(login_tab, text="Screen Name:").grid(row=0, column=0, padx=5, pady=5)
    screen_name_entry = ttk.Entry(login_tab)
    screen_name_entry.grid(row=0, column=1, padx=5, pady=5)
    login_button = ttk.Button(login_tab, text="Login",
                              command=lambda: login_user_and_show_options(screen_name_entry.get(), login_tab))
    login_button.grid(row=1, columnspan=2, pady=5)

def fetch_user_competitions(screen_name, parent):
    new_window = tk.Toplevel(parent)
    new_window.title(f"Contests participated in by {screen_name}")
    new_window.geometry("700x300")
    try:
        connection = connect_to_db()
        cursor = connection.cursor()

        query = """
            SELECT Cont_Name 
            FROM Registers
            WHERE Screen_Name = %s
        """
        cursor.execute(query, (screen_name,))
        results = cursor.fetchall()

        columns = ('Cont_Name')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Cont_Name', text='Contest Name')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)

    except Exception as e:
        print("Error fetching attempted problems:", e)

def fetch_attempted_problems(screen_name, parent):
    new_window = tk.Toplevel(parent)
    new_window.title(f"Problems attempted by {screen_name}")
    new_window.geometry("700x300")
    try:
        connection = connect_to_db()
        cursor = connection.cursor()

        query = """
            SELECT DISTINCT Problem.Prob_ID, Problem.Prob_Name
            FROM Problem INNER JOIN Attempt ON Problem.Prob_ID = Attempt.Prob_ID
            WHERE Attempt.Screen_Name = %s
        """
        cursor.execute(query, (screen_name,))
        results = cursor.fetchall()

        columns = ('Prob_ID', 'Prob_Name')

        tree = ttk.Treeview(new_window, columns=columns, show='headings')
        tree.heading('Prob_ID', text='Problem ID')
        tree.heading('Prob_Name', text='Problem Name')
        tree.pack(fill=tk.BOTH, expand=True, pady=10)

        for result in results:
            tree.insert('', tk.END, values=result)

    except Exception as e:
        print("Error fetching attempted problems:", e)

def create_main_window():
    root = tk.Tk()
    root.title("Codeforces Queries")

    style = ttk.Style()
    style.configure("Treeview",
                    bordercolor="black",
                    borderwidth=1,
                    highlightthickness=1,
                    font=("Arial", 10))

    style.configure("Treeview.Heading",
                    font=("Arial", 12, "bold"),
                    background="lightgrey",
                    foreground="black")

    style.map('Treeview.Heading',
              background=[('active', 'grey')],
              foreground=[('active', 'white')])

    notebook = ttk.Notebook(root)
    notebook.pack(fill='both', expand=True)

    queryTab = ttk.Frame(notebook)
    notebook.add(queryTab, text='Queries')

    login_tab = ttk.Frame(notebook)
    notebook.add(login_tab, text='Login')

    ttk.Label(login_tab, text="Screen Name:").grid(row=0, column=0, padx=5, pady=5)
    screen_name_entry = ttk.Entry(login_tab)
    screen_name_entry.grid(row=0, column=1, padx=5, pady=5)
    login_button = ttk.Button(login_tab, text="Login", command=lambda: login_user_and_show_options(screen_name_entry.get(), login_tab))
    login_button.grid(row=1, columnspan=2, pady=5)

    contest_frame = ttk.LabelFrame(queryTab, text="Contest & Problem Information")
    contest_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

    writers_button = ttk.Button(contest_frame, text='Fetch contests for specific writer',
                                command=lambda: fetch_writer_competitions(queryTab))
    writers_button.grid(row=0, column=0, padx=5, pady=5)

    tag_button = ttk.Button(contest_frame, text='Fetch problems for specific tag',
                            command=lambda: fetch_problems_by_tag(queryTab))
    tag_button.grid(row=0, column=1, padx=5, pady=5)

    top_users_egypt_button = ttk.Button(contest_frame, text='Top 5 problem sets from Egypt',
                                        command=lambda: fetch_top_problems_from_egypt(queryTab))
    top_users_egypt_button.grid(row=2, column=0, padx=5, pady=5)

    users_frame = ttk.LabelFrame(queryTab, text="Top Users")
    users_frame.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")

    top_users_days_button = ttk.Button(users_frame, text='Top 10 users by max days in a row',
                                       command=lambda: fetch_top_user_days(queryTab))
    top_users_days_button.grid(row=2, column=0, padx=5, pady=5)

    top_users_probs_button = ttk.Button(users_frame, text='Top 10 users by total problems solved',
                                        command=lambda: fetch_top_user_probs(queryTab))
    top_users_probs_button.grid(row=0, column=1, padx=5, pady=5)

    top_users_scores_button = ttk.Button(users_frame, text='Top 10 users by total scores',
                                         command=lambda: fetch_top_users_total_scores(queryTab))
    top_users_scores_button.grid(row=1, column=0, padx=5, pady=5)

    top_users_participation_button = ttk.Button(users_frame, text='Top 5 users by participation frequency',
                                                command=lambda: fetch_top_users_by_participation(queryTab))
    top_users_participation_button.grid(row=1, column=1, padx=5, pady=5)

    top_users_auc_button = ttk.Button(users_frame, text='Top 10 AUC users',
                                      command=lambda: fetch_top_auc_users(queryTab))
    top_users_auc_button.grid(row=0, column=0, padx=5, pady=5)



    lang_frame = ttk.LabelFrame(queryTab, text="Language Efficiency")
    lang_frame.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")

    top_lang_speed_button = ttk.Button(lang_frame, text='Top 5 languages by speed efficiency',
                                       command=lambda: fetch_efficient_problems_speed(queryTab))
    top_lang_speed_button.grid(row=0, column=0, padx=5, pady=5)

    top_lang_mem_button = ttk.Button(lang_frame, text='Top 5 languages by memory efficiency',
                                     command=lambda: fetch_efficient_problems_mem(queryTab))
    top_lang_mem_button.grid(row=0, column=1, padx=5, pady=5)

    org_frame = ttk.LabelFrame(queryTab, text="Top Organizations")
    org_frame.grid(row=3, column=0, padx=10, pady=10, sticky="nsew")

    top_organizations_button = ttk.Button(org_frame, text='Top 5 organizations by country',
                                          command=lambda: fetch_top_organizations_by_country(queryTab))
    top_organizations_button.grid(row=0, column=0, padx=5, pady=5)

    queryTab.columnconfigure(0, weight=1)
    queryTab.rowconfigure(3, weight=1)

    root.mainloop()


create_main_window()
