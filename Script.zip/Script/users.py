import requests
import json
from datetime import datetime, timezone, timedelta
import csv
import time

csv_file_path_user = 'user_output.csv'

def extract_user_info(users):
    extracted_info = []

    for user in users:
        regtime = user['registrationTimeSeconds']
        registration_date = datetime.fromtimestamp(regtime, timezone.utc).strftime('%Y-%m-%d')
        extracted_info.append({
          'Screen_Name' : user['handle'],
          'User_City': user.get('city', ''),
          'User_Country': user.get('country', ''),
          'User_Org': user.get('organization', ''),
          'Contribution': user.get('contribution', 0),
          'Friends_No': user.get('friendOfCount', 0),
          'Reg_Date' : registration_date,
          'Rating': user.get('rating', 0)
        })
    return extracted_info

def fetch_users(user):
    urlStandings = f'https://codeforces.com/api/user.info?handles={user}&checkHistoricHandles=false'
    retries = 3
    for attempt in range(retries):
        try:
            responseStand = requests.get(urlStandings)
            responseStand.raise_for_status()
            data = responseStand.json()

            if data.get('status') != 'OK':
                print(f"Error fetching info for user {user}: {data.get('comment', 'No comment')}")
                return None

            return data['result']
        except requests.exceptions.RequestException as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                time.sleep(2)
            else:
                print(f"Failed to fetch info for user {user} after {retries} attempts.")
                return None

with open('new_fix.txt', 'r') as f:
    usernames = [line.strip() for line in f.readlines()]

for username in usernames:
    users_data = fetch_users(username)

    if users_data:
        users_out = extract_user_info(users_data)
        with open('users_output.json', 'w') as h:
            json.dump(users_out, h, indent=4)

        with open('users_output.json', 'r') as json_file_user:
            users = json.load(json_file_user)

        with open(csv_file_path_user, 'a', newline='', encoding='utf-8') as csv_file_user:
            writer_user = csv.writer(csv_file_user)

            for user in users:
                writer_user.writerow([
                    user['Screen_Name'],
                    user['User_City'],
                    user['User_Country'],
                    user['User_Org'],
                    user['Contribution'],
                    user['Friends_No'],
                    user['Reg_Date'],
                    user['Rating']
                ])

