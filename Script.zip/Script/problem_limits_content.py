from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import undetected_chromedriver as uc
import time
import random

# Set up options for undetected ChromeDriver
options = uc.ChromeOptions()
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("user-agent=Your Custom User Agent Here")  # Add your user agent
options.add_argument("--start-maximized")  # Start maximized to mimic human behavior

driver = uc.Chrome(options=options)

url = 'https://codeforces.com/problemset/problem/2020/F'
driver.get(url)


# Add a delay to mimic human behavior
time.sleep(random.uniform(2, 5))  # Random delay between 2 and 5 seconds

# Wait for the specific parent div to be present
try:
    parent_div = WebDriverWait(driver, 100).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'your_parent_class_name'))  # Replace with actual parent class name
    )
    print("Parent div found.")
except Exception as e:
    print("Failed to load parent div:", e)
    driver.quit()
    exit()

# Now wait specifically for the inner div you want to remove
try:
    inner_div_to_remove = WebDriverWait(driver, 100).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'your_inner_class_name'))  # Replace with actual inner class name
    )
    driver.execute_script("arguments[0].remove();", inner_div_to_remove)
    print("Inner div removed.")
except Exception as e:
    print("Inner div not found or could not be removed:", e)
    driver.quit()
    exit()

# Now extract the text content of the parent div after removing the inner div
try:
    remaining_text = parent_div.text  # Get the text content of the parent div
    print("Remaining text:", remaining_text)  # Print the cleaned text content
except Exception as e:
    print("Error accessing parent div content:", e)

driver.quit()






























# import requests
# from bs4 import BeautifulSoup
# import pandas
# import re
# import time
# import urllib.request
#
# url = 'https://codeforces.com/problemset/problem/2020/F'
#
# request = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'})
# response = urllib.request.urlopen(request)
# soup = BeautifulSoup(response, 'html.parser')
#
# problem_statement = soup.find(class_='problem-statement')
#
# # Get the text inside the tag
# if problem_statement:
#     print(problem_statement.get_text(strip=True))
#
