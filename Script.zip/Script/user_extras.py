import csv
import time
from bs4 import BeautifulSoup
import undetected_chromedriver as uc


csv_file_user_extra = 'user_extra.csv'


def fetch_prob_extras(driver, user):
    try:
        driver.set_page_load_timeout(20)
        url = f'https://codeforces.com/profile/{user}'
        driver.get(url)
        print(f"Fetching URL: {url}")

        # Parse the page
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        user_stuff = soup.find('div', class_='_UserActivityFrame_frame')
        problems_solved = 0
        days_in_row = 0

        if user_stuff:
            counters = user_stuff.find_all('div', class_='_UserActivityFrame_counter')

            for counter in counters:
                number = counter.find('div', class_='_UserActivityFrame_counterValue').get_text(strip=True)

                if "problems" in number:
                    current_num = int(number.split()[0])
                    problems_solved = max(problems_solved, current_num)
                elif "days" in number:
                    current_num = int(number.split()[0])
                    days_in_row = max(days_in_row, current_num)
            return problems_solved, days_in_row

    except Exception as e:
        print(f"Error fetching info for problem {user}: {e}")
        time.sleep(3)
        return None


def main():
    options = uc.ChromeOptions()
    options.headless = False
    driver = uc.Chrome(options=options)

    users = []
    with open('usernames.txt', 'r', encoding='utf-8') as f:
        for line in f:
            users.append(line.strip())


    with open(csv_file_user_extra, 'a', newline='', encoding='utf-8') as csv_file_extra_user:
        writer = csv.writer(csv_file_extra_user)

        try:
            for user in users:

                extras = fetch_prob_extras(driver, user)
                if extras:
                    writer.writerow([extras[0],extras[1]])
                time.sleep(2)

        finally:
            driver.quit()
            print("Driver closed and data saved.")



if __name__ == "__main__":
    main()