import csv
import time
import random
from bs4 import BeautifulSoup
import undetected_chromedriver


csv_file_path_writers = 'contest_writers_output.csv'


with open('C:/Users/asus/OneDrive/Desktop/Fall 2024/Database/Projects/Project 1/CodeCrawler/codeforces_crawler/codeforces_crawler/spiders/contest_ids', 'r') as f:
    contest_ids = [line.strip() for line in f.readlines()]

def fetch_writers(driver, page):
    try:
        driver.set_page_load_timeout(20)
        driver.get(f'https://codeforces.com/contests/page/{page}')

        time.sleep(random.uniform(2, 4))

        info = driver.page_source
        soup = BeautifulSoup(info, 'html.parser')
        contests_on_page = soup.find_all('tr', {'data-contestid': True})

        if not contests_on_page:
            print(f"No contests found on page {page}. Page content:\n{info[:500]}...")

        for contest_row in contests_on_page:
            cont_id = contest_row.get('data-contestid')


            if cont_id in contest_ids:
                contest_name_td = contest_row.find('td', class_='left')
                contest_title = contest_name_td.get_text(strip=True).split('\n')[0]
                print(f"Contest title: {contest_title}")


                writer_td = contest_row.find('td', class_='small')
                profile_links = writer_td.find_all('a', href=True) if writer_td else []

                with open(csv_file_path_writers, 'a', newline='', encoding='utf-8') as csv_file_write:
                    writer_write = csv.writer(csv_file_write)
                    for link in profile_links:
                        writer_name = link.text.strip()
                        writer_write.writerow([contest_title, writer_name])
                    print(f"Wrote writers for contest ID: {cont_id}")

    except Exception as e:
        print(f"Error fetching info for page {page}: {e}")


if __name__ == "__main__":

    options = undetected_chromedriver.ChromeOptions()
    options.headless = False
    driver = undetected_chromedriver.Chrome(options=options)

    try:

        for page in range(1, 20):
            fetch_writers(driver, page)
            time.sleep(random.uniform(2, 5))
    finally:
        driver.quit()
