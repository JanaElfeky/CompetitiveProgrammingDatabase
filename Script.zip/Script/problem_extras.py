import csv
import time
import re
from bs4 import BeautifulSoup
import undetected_chromedriver as uc


csv_file_path_prob_extra = 'problem_extras_output.csv'



def load_problem_ids(filepath, start_id):
    prob_ids = []
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            prob_id = line.split(',', 1)[0].strip()
            prob_ids.append(prob_id)

    try:
        start_index = prob_ids.index(start_id)
        return prob_ids[start_index + 1:]
    except ValueError:
        print(f"Start ID {start_id} not found.")
        return []



def split_id(id):
    match = re.match(r'(\d+)([A-Za-z0-9]*)', id)
    return (match.group(1), match.group(2)) if match else (None, None)



def fetch_prob_extras(driver, num, letter):
    try:
        driver.set_page_load_timeout(20)
        url = f'https://codeforces.com/problemset/problem/{num}/{letter}'
        driver.get(url)
        print(f"Fetching URL: {url}")


        soup = BeautifulSoup(driver.page_source, 'html.parser')
        problem_statement_div = soup.find('div', class_='problem-statement')

        if problem_statement_div:
            paragraphs = problem_statement_div.find_all('p')
            problem_statement = ' '.join(p.get_text(strip=True) for p in paragraphs)
            return problem_statement

        else:
            print(f"Problem statement div not found for {num}{letter}")
            return None


    except Exception as e:
        print(f"Error fetching info for problem {num}{letter}: {e}")
        time.sleep(3)  # Brief delay before retry
        return None


def main():

    options = uc.ChromeOptions()
    options.headless = False
    driver = uc.Chrome(options=options)

    prob_ids = load_problem_ids(
        'C:/Users/asus/OneDrive/Desktop/Fall 2024/Database/Projects/Project 1/CodeCrawler/codeforces_crawler/codeforces_crawler/spiders/problems_output.csv',
        '958F1'
    )

    split_ids = [split_id(id) for id in prob_ids]
    split_ids = [sid for sid in split_ids if sid[0] and sid[1]]

    with open(csv_file_path_prob_extra, 'a', newline='', encoding='utf-8') as csv_file_extra_stat:
        writer = csv.writer(csv_file_extra_stat)

        try:
            for num, letter in split_ids:
                problem_statement = fetch_prob_extras(driver, num, letter)
                if problem_statement:
                    writer.writerow([problem_statement])
                time.sleep(2)
        finally:
            driver.quit()
            print("Driver closed and data saved.")


if __name__ == "__main__":
    main()