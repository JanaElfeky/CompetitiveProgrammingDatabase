import requests
import json
from datetime import datetime, timezone, timedelta
import csv
import time

urlContests = 'https://codeforces.com/api/contest.list'
responseCont = requests.get(urlContests)
api_response_Cont = responseCont.json()

csv_file_path_cont = 'contests_output.csv'
csv_file_path_stand = 'standings_output.csv'
csv_file_path_inc = 'includings_output.csv'
csv_file_path_att = 'attempts_output.csv'

def extract_contest_info(contests):
    extracted_info = []
    contest_ids = []

    for contest in contests:
        if contest['relativeTimeSeconds'] >= 0:

            start_date_utc = datetime.fromtimestamp(contest['startTimeSeconds'], timezone.utc)
            start_date_utc_3 = start_date_utc + timedelta(hours=3.0)
            start_date = start_date_utc_3.strftime('%Y-%m-%d %H:%M:%S')
            duration_hours = contest['durationSeconds'] / 3600


            if 'Div. 1' in contest['name'] and 'Div. 2' in contest['name']:
                division = 'Unknown'
            elif 'Div. 1' in contest['name']:
                division = 'Div. 1'
                contest_ids.append(contest['id'])
            elif 'Div. 2' in contest['name']:
                division = 'Div. 2'
                contest_ids.append(contest['id'])
            else:
                division = 'Unknown'

            extracted_info.append({
                'name': contest['name'],
                'division': division,
                'duration_hours': duration_hours,
                'start_date': start_date
            })

    contest_ids = contest_ids[1:]
    return extracted_info, contest_ids

def extract_division(division_text):
    if 'Div. 1' in division_text:
        return '1'
    elif 'Div. 2' in division_text:
        return '2'
    else:
        return None

def extract_standings_info(standings):
    extracted_info = []
    usernames = []
    contest_name = standings['result']['contest']['name']

    for row in standings['result']['rows']:

        if len(row['party']['members'])==1:
            handle = row['party']['members'][0]['handle']
            rank = row['rank']
            points = row['points']
            usernames.append(handle)
        else:
            handle = ''
            rank = ''
            points = ''

        extracted_info.append({
            'Cont_Name': contest_name,
            'Screen_Name': handle,
            'Total_Score': points,
            'Standing': rank
        })

    return extracted_info, usernames

def extract_including_info(includes):
    extracted_info = []
    contest_name = includes['result']['contest']['name']

    for include in includes['result']['problems']:
        prob_id = str(include['contestId']) + include['index']
        extracted_info.append({
            'Prob_ID': prob_id,
            'Cont_Name': contest_name,
            'Letter' : include['index']
        })
    return extracted_info

def extract_attempt_info(attempts):
    extracted_info = []

    for attempt in attempts['result']:
        start_date_utc = datetime.fromtimestamp(attempt['author']['startTimeSeconds'], timezone.utc)
        start_date_utc_3 = start_date_utc + timedelta(hours=3.0)
        start_date = start_date_utc_3.strftime('%Y-%m-%d %H:%M:%S')
        prob_id = str(attempt['problem']['contestId']) + attempt['problem']['index']
        duration = attempt['timeConsumedMillis'] / 1000
        memory = attempt['memoryConsumedBytes'] / (1024 * 1024)
        if len(attempt['author']['members'])==1:
            handle = attempt['author']['members'][0]['handle']
        else:
            handle = ''
        extracted_info.append({
            'Prob_ID': prob_id,
            'Sub_ID': attempt['id'],
            'Att_Date': start_date,
            'Screen_Name': handle,
            'Att_Duration' : duration,
            'Att_Mem' : memory,
            'Lang' : attempt['programmingLanguage'],
            'Verdict' : attempt['verdict']
        })

    return extracted_info

def fetch_standings(cont_id):
    urlStandings = f'https://codeforces.com/api/contest.standings?contestId={cont_id}&showUnofficial=false'
    retries = 3
    for attempt in range(retries):
        try:
            responseStand = requests.get(urlStandings)
            responseStand.raise_for_status()
            data = responseStand.json()

            if data.get('status') != 'OK':
                print(f"Error fetching standings for contest ID {cont_id}: {data.get('comment', 'No comment')}")
                return None

            return data
        except requests.exceptions.RequestException as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                time.sleep(2)
            else:
                print(f"Failed to fetch standings for contest ID {cont_id} after {retries} attempts.")
                return None

def fetch_attempts(cont_id):
    urlStandings = f'https://codeforces.com/api/contest.status?contestId={cont_id}&showUnofficial=false'
    retries = 3
    for attempt in range(retries):
        try:
            responseStand = requests.get(urlStandings)
            responseStand.raise_for_status()
            data = responseStand.json()

            if data.get('status') != 'OK':
                print(f"Error fetching standings for contest ID {cont_id}: {data.get('comment', 'No comment')}")
                return None

            return data
        except requests.exceptions.RequestException as e:
            print(f"Attempt {attempt + 1} failed: {e}")
            if attempt < retries - 1:
                time.sleep(2)
            else:
                print(f"Failed to fetch standings for contest ID {cont_id} after {retries} attempts.")
                return None


contests = api_response_Cont["result"]
valid_contests = extract_contest_info(contests)[0]
contest_ids = extract_contest_info(contests)[1]

with open('contests_output.json', 'w') as f:
    json.dump(valid_contests, f, indent=4)

with open('contests_output.json', 'r') as json_file_cont:
    contests = json.load(json_file_cont)


with open(csv_file_path_cont, 'w', newline='', encoding='utf-8') as csv_file_cont: #for contests
    writer_cont = csv.writer(csv_file_cont)
    for contest in contests:
        division = extract_division(contest['division'])
        if division == '1' or division == '2':
            writer_cont.writerow([
                contest['name'],
                contest['duration_hours'],
                contest['start_date'],
                division
            ])

for cont_id in contest_ids: #for includes

    includes_data = fetch_standings(cont_id)
    if includes_data:
        includes_out = extract_including_info(includes_data)
        with open('new_includes_output.json', 'w') as h:
            json.dump(includes_out, h, indent=4)

        with open('new_includes_output.json', 'r') as json_file_inc:
            includes = json.load(json_file_inc)

        with open(csv_file_path_inc, 'a', newline='', encoding='utf-8') as csv_file_inc:
            writer_inc = csv.writer(csv_file_inc)
            for include in includes:
                writer_inc.writerow([
                    include['Prob_ID'],
                    include['Cont_Name'],
                    include['Letter']
                ])

for cont_id in contest_ids: #for attempts

    attempts_data = fetch_attempts(cont_id)
    if attempts_data:
        attempts_out = extract_attempt_info(attempts_data)
        with open('attempts_output.json', 'w') as i:
            json.dump(attempts_out, i, indent=4)

        with open('attempts_output.json', 'r') as json_file_att:
            attempts = json.load(json_file_att)

        with open(csv_file_path_att, 'a', newline='', encoding='utf-8') as csv_file_att:
            writer_att = csv.writer(csv_file_att)
            for attempt in attempts:
                writer_att.writerow([
                    attempt['Prob_ID'],
                    attempt['Sub_ID'],
                    attempt['Att_Date'],
                    attempt['Screen_Name'],
                    attempt['Att_Duration'],
                    attempt['Att_Mem'],
                    attempt['Lang'],
                    attempt['Verdict']
                ])

for cont_id in contest_ids: #for standings

    standings_data = fetch_standings(cont_id)
    if standings_data:
        standings_out = extract_standings_info(standings_data)
        usernames = extract_standings_info(standings_data)[1]

        with open('standings_output.json', 'w') as h:
            json.dump(standings_out, h, indent=4)

        with open('standings_output.json', 'r') as json_file_stand:
            standings = json.load(json_file_stand)


        with open(csv_file_path_stand, 'a', newline='', encoding='utf-8') as csv_file_stand:
            writer_stand = csv.writer(csv_file_stand)
            for stand in standings:
                total_score = int(stand['Total_Score']) if stand['Total_Score'] else 0
                writer_stand.writerow([
                    stand['Cont_Name'],
                    stand['Screen_Name'],
                    total_score,
                    stand['Standing']
                ])
    with open('usernames.txt', 'w') as file:
        for element in usernames:
            file.write(f"{element}\n")
